Caltech CS2 Assignment 3: Data Structures

See [assignment3.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/maze/blob/master/assignment3.html)
