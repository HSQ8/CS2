/**
 * @file
 * @author The CS2 TA Team
 * @version 1.0
 * @date 2013-2014
 * @copyright This code is in the public domain.
 *
 * @brief Student implementation of line algorithm.
 *
 */
#include "LineAlgorithm.hpp"

/**
 * TODO: Implement a line algorithm of your choice here.
 */
vector<Tuple> line(Tuple p1, Tuple p2)
{
    vector<Tuple> v;
    return v;
}
