/**
 * @file
 * @author The CS2 TA Team
 * @version 1.0
 * @date 2013-2014
 * @copyright This code is in the public domain.
 *
 * @brief The gift wrapping and Graham scan convex hull algorithms
 * (header file). 
 * this contains the implementations of the Giftwarp as well as the Graham scan algorithm.
 * the basis of the giftwrap algorithm is that it continuaously looks for points such that
 * the line formed by that point and the current point would divide all points
 * to one side, thus forming a convex hull that captures the set of points.
 *
 */

#include <vector>
#include <cstdlib>
#include <stdlib.h>
#include <iostream>
#include "ConvexHullApp.hpp"
#include "structs.hpp"

using namespace std;

void DoGiftWrap(vector<Tuple*> points, ConvexHullApp *app);
void DoGrahamScan(vector<Tuple*> points, ConvexHullApp *app);

void swapnum(std::vector<double> &list, int indexA, int indexB);
int pivotNum(std::vector<double>& v, int low, int high, vector<Tuple*> &points);
void swapPointer(vector<Tuple*> &points, int a1, int a2);
void quicksort_inplace(std::vector<double> &list, int left, int right, vector<Tuple*> &points);
void swapPointer(vector<Tuple*> &points, int a1, int a2);
void sort(vector<Tuple*> &points, vector<double> &angles);

double getPointAngle(Tuple* point1, Tuple* point2);
double getTripletAngle(Tuple* point3,Tuple* vertex,Tuple* point1);
