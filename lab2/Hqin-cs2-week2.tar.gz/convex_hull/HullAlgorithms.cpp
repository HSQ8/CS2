/**
 * @file
 * @author The CS2 TA Team
 * @version 1.0
 * @date 2013-2014
 * @copyright This code is in the public domain.
 *
 * @brief The gift wrapping and Graham scan convex hull algorithms
 * (implementation).
 *
 */
#include <algorithm>
#include "HullAlgorithms.hpp"
#include <cmath>

/*
 _   _  ___ _____ _____ 
| \ | |/ _ \_   _| ____|
|  \| | | | || | |  _|  
| |\  | |_| || | | |___ 
|_| \_|\___/ |_| |_____|
                        
I'm note sure how much I am able to change the anglesort Cpp since it counts as 1 point, 
so I wasn't able to directly reuse the thing because of the main method conflict. 
If there's a way to resolve this I'd love to know. As for now, I've just pasted the same code in here. 
Hopefully thats not too ugly.
*/

/**
 * TO STUDENTS: In all of the following functions, feel free to change the
 * function arguments and/or write helper functions as you see fit. Remember to
 * add the function header to HullAlgorithms.hpp if you write a helper function!
 *
 * Our reference implementation has four helper functions and the function(s)
 * copied over from angleSort.cpp.
 */

/**
 * TODO: Implement this function.
 */





/**
 * pivotNum is a pivot function that selects a pivot
 * then uses that pivot to organize all points greater than it above it
 * and all points lower than it below it.
 * this uses two indicies to keep track of the location of the low and high swaps
 * and then swaps the pivot value into the appropriate place
 */
int pivotNum(std::vector<double>& v, int low, int high, vector<Tuple*> &points){
    int i = low - 1;
    int pivot = high;
    for(int j = low; j < high; ++j){
        if (v.at(j) < v.at(pivot)){
            i++;
            swapnum(v,i,j);
            swapPointer(points, i, j);
        }
    }
    swapnum(v, i + 1, high);
    swapPointer(points, i + 1, high);
    return i+1;
}

/*
 * quicksort_inplace:  In-place version of the quicksort algorithm. Requires
 *              O(1) instead of O(N) space, same time complexity. Each call of
 *              the method partitions the list around the pivot (an item taken
 *              from the middle of the array) with items left of the pivot
 *              smaller than it and items to its right larger than it. Then the
 *              method recursively sorts the left and right portions of the list
 *              until it reaches its base case: a list of length 1 is already
 *              sorted.

 note - this version has been modified to take in an additional vector of points
 so that the points can be swapped inthe same fashion as the angles.
 *
 * @param list: pointer to integer array to be sorted
 * @returns:    Nothing, the array is sorted IN-PLACE.
 *
 * TODO: Implement this function.
 */
void quicksort_inplace(std::vector<double> &list, int left, int right, vector<Tuple*> &points)
{
    if (left < right){
        int pivot = pivotNum(list, left,right, points);
        quicksort_inplace(list,pivot + 1, right, points);
        quicksort_inplace(list,left, pivot - 1, points);
    }
}


// swapPointer is a function which takes a vector reference, and two index locations
// and swaps the pointer values of the vector at that location
// input list = the list to swap
// input indexA = the first index to swap
// input indexB = the second index to swap
// return nothing

void swapPointer(vector<Tuple*> &points, int a1, int a2){
    Tuple * tempPtr = points.at(a1);
    points.at(a1) = points.at(a2);
    points.at(a2) = tempPtr;
}


// swapnum is a function which takes a vector reference, and two index locations
// and swaps the values of the vector at that location
// input list = the list to swap
// input indexA = the first index to swap
// input indexB = the second index to swap
// return nothing

void swapnum(std::vector<double> &list, int indexA, int indexB){
    double temp = list.at(indexA);
    list.at(indexA) = list.at(indexB);
    list.at(indexB) = temp;
}

//sort function takes in a vector of angles <double> and a vector 
// of point tuples and sorts them in ascending order. the underlying algorithm uses
// quicksort, but slightly modified to take in an extra argument list and mirror the 
// operations of the list on it.
void sort(vector<Tuple*> &points, vector<double> &angles)
{
    quicksort_inplace(angles, 0, angles.size() - 1, points);
    
}

// get point angle returns the angle of the line formed by point1 and point2 with respect to the normal axis
// y axis. It returns the angle as a double clockwise from the +y axis in a cartesian system.
double getPointAngle(Tuple* point1, Tuple* point2){
    int dx = point2->x - point1->x;
    int dy = point2->y - point1->y;
    if(point1->x == point2->x){
        if (dy < 0){
            return 180.0;
        }else{
            return 0.0;
        }
    }else if(point1->y == point2->y){
        if(dx < 0){
            return 270.0;
        }else{
            return 90.0;
        }
    }else if(dx > 0 && dy > 0){
        return 90 - std::atan2(dy,dx) * 180 / M_PI;

    }else if(dx < 0 && dy > 0){
        return 180 - std::atan2(dy,dx) * 180 / M_PI + 270;
    }else if(dx > 0 && dy < 0){
        return 90 - std::atan2(dy,dx) * 180 / M_PI;
        
    }else if(dx < 0 && dy < 0){
        return 90 - std::atan2(dy,dx) * 180 / M_PI;
    }
    return 0.0;
}


// the gift wrap algorithm first selects the left most point, then it
// iteratest through all the points to compute the angle between the 
// +y axis (assume cartesian plane) and the line formed by the current point
// and the next perspective point.
// it finds the smallest angle that is larger than the previous turn angle, thus 
// locating the next point on the convexhull that would ensure that
// no point would lie outside this line
// then it appends that point to the hull
// it stops searching once it returns to the beginning.
void DoGiftWrap(vector<Tuple*> points, ConvexHullApp *app)
{
    //finds leftmost point
    Tuple* start = points.at(0);
    for(auto i: points){
        if (i->x < start->x){
            start = i;
        }
    }
    // adds the first point to the hull
    Tuple* current = start;
    Tuple* next = points[1];
    app->add_to_hull(start);
    double prevangle = 0;
    //main algorithm as described above
    while(next != start){
        //std::cout << "here"<<endl;
     double currentangle = 360.0;   
     for(auto i:points){

        if(i != current){
            double newangle = getPointAngle(current, i);
            if(currentangle > newangle && newangle > prevangle){

                currentangle = newangle;
                next = i;
                    //cout << "ifloop" << endl;
            }
        }
    }
    prevangle = currentangle;
    app->add_to_hull(next);
    current = next;
}
}

//get triplet angle takes three points and computes the angle of the vertex formed
// by these three points. The angles are always swept counterclockwise from the two lines.
// @ param - point1 vertex point3, the points are pointers to tuples of xy value pairs
// @return double of the counterclockwise angle swept by the two lines
double getTripletAngle(Tuple* point3,Tuple* vertex,Tuple* point1){
    double x1 = point1->x - vertex->x;
    double y1 = point1->y - vertex->y;
    double x2 = point3->x - vertex->x;
    double y2 = point3->y - vertex->y;
    double dot = x1*x2 + y1*y2;
    double det = x1*y2 - y1*x2;
    double angle = atan2(det,dot) * 180 / M_PI;
    if(angle < 0)
        angle += 360;
    return angle;
}
 /**
 * the graham scan algorithm first finds the lowest point, then it computes the 
 angles between the vetex formed by the lowest point, the origin, and each other point,
 and sorts the following points in that order.
 it then adds three initial points to the hull and iteratively adds points to the hull while
 using getTripletAngle to determine whether the newest three poings added are making a convex left turn,
 if yes then we continue to add points until we reach then end. If we get a concave angle, then we 
 back track and delete the 2nd to alst point added and recompute the angle until all angles are convex, 
 thus ensuring that all points will be in the convex hull.
 */
void DoGrahamScan(vector<Tuple*> points, ConvexHullApp *app)
{
    // fines the lowest point
    Tuple* start = points.at(0);
    for(auto i: points){
        if (i->x < start->x){
            start = i;
        }
    }
    
    //computes all the angles
    Tuple* origin = new Tuple(0,0);
    std::vector<double> angles;
    for(auto i:points){
        angles.push_back(getPointAngle(start, i) - getPointAngle(start, origin));
    }
    // sort the angles
    sort(points, angles);
    //makes a list of points so we can modify it without modifying the
    // original input list incase we wanted to use the other algorithm
    std::vector<Tuple*> mypoints;
    for(auto i: points){
        mypoints.push_back(i);
    }
//erase the start since it has already been added
    auto it = std::find(mypoints.begin(),mypoints.end(),start);
    if (it != mypoints.end()) {
      mypoints.erase(it);
  }
  // add the first two points and start, while erasing appropriate points
  // that have already been added
  mypoints.push_back(start);
  std::vector<Tuple*> path;
  path.push_back(start);
  path.push_back(mypoints.at(0));
  mypoints.erase(mypoints.begin());
  path.push_back(mypoints.at(0));
  mypoints.erase(mypoints.begin());
  //main algorithm as described above
  double angle;
  for (auto i: mypoints){
    path.push_back(i);
    angle = getTripletAngle(path.at(path.size() - 1), path.at(path.size() - 2),path.at(path.size() - 3));
    //cout << path.size() << endl;
        //std::cout << "whileout" << angle << endl;
    while(angle >= 180){
        //cout << path.size() << endl;
        //std::cout << "while" << angle << endl;
        path.erase(path.end() - 2);
        angle = getTripletAngle(path.at(path.size() - 1), path.at(path.size() - 2),path.at(path.size() - 3));
        
    }
    
}
//adds the path found to hull
for (auto i: path){
    app->add_to_hull(i);
}

}