backwards Euler - 
over compensates, orbit gets smaller and smaller until it satellite collides with star

forwards Euler - under compensates, orbit gets larger and larger and eventually the satellite goes off screen.

symplectic Euler - seems about right
orbit is a ellipse around star with appropriate variation in distance from satellite to main star.