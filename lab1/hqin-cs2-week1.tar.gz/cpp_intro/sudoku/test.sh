#!/bin/bash

./sudoku < test/test1.in > test/test1.out
./sudoku < test/test2.in > test/test2.out
./sudoku < test/test3.in > test/test3.out
./sudoku < test/test4.in > test/test4.out
./sudoku < test/test5.in > test/test5.out
./sudoku < test/test6.in > test/test6.out
./sudoku < test/test7.in > test/test7.out
./sudoku < test/test8.in > test/test8.out
