# include "grid.hpp"
using namespace std;
class game{
private:
    grid mygrid;
public:
    void getMove() ;
    void run();
    game();
    ~game();
};