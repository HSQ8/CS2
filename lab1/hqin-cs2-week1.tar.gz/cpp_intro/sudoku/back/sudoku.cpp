#include "game.hpp"
int main(){
    // main function, instatiates a game object and runs the game
    game mygame = game();
    mygame.run();
    return 0;
}